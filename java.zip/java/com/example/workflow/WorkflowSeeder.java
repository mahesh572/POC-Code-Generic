package com.example.workflow;

import com.example.workflow.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

@Configuration
@RequiredArgsConstructor
public class WorkflowSeeder {

    private final WorkflowDefinitionRepository workflowDefinitionRepository;
    private final WorkflowStateRepository workflowStateRepository;
    private final WorkflowActionDefinitionRepository actionDefinitionRepository;
    private final WorkflowTransitionRepository workflowTransitionRepository;

    private final RoleRepository roleRepository;
    private final PermissionRepository permissionRepository;

    @Bean
    CommandLineRunner seedWorkflowData() {
        return args -> seedInvoiceWorkflow();
    }

    @Transactional
    public void seedInvoiceWorkflow() {

        // =========================================================
        // 1. ROLES
        // =========================================================

        Role maker = findOrCreateRole(
                "MAKER",
                "Maker"
        );

        Role approver = findOrCreateRole(
                "APPROVER",
                "Approver"
        );

        Role financeManager = findOrCreateRole(
                "FINANCE_MANAGER",
                "Finance Manager"
        );

        Role admin = findOrCreateRole(
                "ADMIN",
                "Administrator"
        );

        // =========================================================
        // 2. PERMISSIONS
        // =========================================================

        Map<String, Permission> permissions = new HashMap<>();

        Permission invoiceView =
                findOrCreatePermission(
                        "INVOICE_VIEW",
                        "View Invoice"
                );

        Permission invoiceCreate =
                findOrCreatePermission(
                        "INVOICE_CREATE",
                        "Create Invoice"
                );

        Permission invoiceSubmit =
                findOrCreatePermission(
                        "INVOICE_SUBMIT",
                        "Submit Invoice"
                );

        Permission invoiceApprove =
                findOrCreatePermission(
                        "INVOICE_APPROVE",
                        "Approve Invoice"
                );

        Permission invoiceReject =
                findOrCreatePermission(
                        "INVOICE_REJECT",
                        "Reject Invoice"
                );

        Permission invoiceSendBack =
                findOrCreatePermission(
                        "INVOICE_SEND_BACK",
                        "Send Invoice Back"
                );

        Permission invoiceCancel =
                findOrCreatePermission(
                        "INVOICE_CANCEL",
                        "Cancel Invoice"
                );

        permissions.put("INVOICE_VIEW", invoiceView);
        permissions.put("INVOICE_CREATE", invoiceCreate);
        permissions.put("INVOICE_SUBMIT", invoiceSubmit);
        permissions.put("INVOICE_APPROVE", invoiceApprove);
        permissions.put("INVOICE_REJECT", invoiceReject);
        permissions.put("INVOICE_SEND_BACK", invoiceSendBack);
        permissions.put("INVOICE_CANCEL", invoiceCancel);

        // =========================================================
        // 3. ASSIGN PERMISSIONS TO ROLES
        // =========================================================

        // MAKER
        assignPermission(maker, invoiceView);
        assignPermission(maker, invoiceCreate);
        assignPermission(maker, invoiceSubmit);

        // APPROVER
        assignPermission(approver, invoiceView);
        assignPermission(approver, invoiceApprove);
        assignPermission(approver, invoiceReject);
        assignPermission(approver, invoiceSendBack);

        // FINANCE MANAGER
        assignPermission(financeManager, invoiceView);
        assignPermission(financeManager, invoiceApprove);
        assignPermission(financeManager, invoiceReject);
        assignPermission(financeManager, invoiceSendBack);

        // ADMIN
        assignPermission(admin, invoiceView);
        assignPermission(admin, invoiceCreate);
        assignPermission(admin, invoiceSubmit);
        assignPermission(admin, invoiceApprove);
        assignPermission(admin, invoiceReject);
        assignPermission(admin, invoiceSendBack);
        assignPermission(admin, invoiceCancel);

        // =========================================================
        // 4. WORKFLOW DEFINITION
        // =========================================================

        WorkflowDefinition workflow =
                workflowDefinitionRepository
                        .findByCodeAndVersion(
                                "INVOICE_APPROVAL",
                                1
                        )
                        .orElseGet(() ->
                                workflowDefinitionRepository.save(
                                        WorkflowDefinition.builder()
                                                .code("INVOICE_APPROVAL")
                                                .name("Invoice Approval")
                                                .description(
                                                        "Invoice approval workflow"
                                                )
                                                .version(1)
                                                .active(true)
                                                .build()
                                )
                        );

        // =========================================================
        // 5. WORKFLOW STATES
        // =========================================================

        Map<String, WorkflowState> states = new HashMap<>();

        states.put(
                "DRAFT",
                findOrCreateState(
                        workflow,
                        "DRAFT",
                        "Draft",
                        "Invoice is being prepared",
                        true,
                        false,
                        1
                )
        );

        states.put(
                "PENDING_APPROVAL",
                findOrCreateState(
                        workflow,
                        "PENDING_APPROVAL",
                        "Pending Approval",
                        "Invoice is waiting for approval",
                        false,
                        false,
                        2
                )
        );

        states.put(
                "APPROVED",
                findOrCreateState(
                        workflow,
                        "APPROVED",
                        "Approved",
                        "Invoice has been approved",
                        false,
                        true,
                        3
                )
        );

        states.put(
                "REJECTED",
                findOrCreateState(
                        workflow,
                        "REJECTED",
                        "Rejected",
                        "Invoice has been rejected",
                        false,
                        true,
                        4
                )
        );

        states.put(
                "CANCELLED",
                findOrCreateState(
                        workflow,
                        "CANCELLED",
                        "Cancelled",
                        "Invoice has been cancelled",
                        false,
                        true,
                        5
                )
        );

        // =========================================================
        // 6. WORKFLOW ACTION DEFINITIONS
        // =========================================================

        Map<String, WorkflowActionDefinition> actions =
                new HashMap<>();

        actions.put(
                "SUBMIT",
                findOrCreateAction(
                        workflow,
                        "SUBMIT",
                        "Submit",
                        "Submit invoice for approval",
                        1,
                        "primary",
                        false
                )
        );

        actions.put(
                "APPROVE",
                findOrCreateAction(
                        workflow,
                        "APPROVE",
                        "Approve",
                        "Approve the invoice",
                        2,
                        "success",
                        false
                )
        );

        actions.put(
                "REJECT",
                findOrCreateAction(
                        workflow,
                        "REJECT",
                        "Reject",
                        "Reject the invoice",
                        3,
                        "danger",
                        true
                )
        );

        actions.put(
                "SEND_BACK",
                findOrCreateAction(
                        workflow,
                        "SEND_BACK",
                        "Send Back",
                        "Send invoice back to draft",
                        4,
                        "warning",
                        true
                )
        );

        actions.put(
                "CANCEL",
                findOrCreateAction(
                        workflow,
                        "CANCEL",
                        "Cancel",
                        "Cancel the invoice",
                        5,
                        "danger",
                        true
                )
        );

        // =========================================================
        // 7. WORKFLOW TRANSITIONS + REQUIRED PERMISSION
        // =========================================================

        createTransition(
                workflow,
                states.get("DRAFT"),
                actions.get("SUBMIT"),
                states.get("PENDING_APPROVAL"),
                permissions.get("INVOICE_SUBMIT")
        );

        createTransition(
                workflow,
                states.get("PENDING_APPROVAL"),
                actions.get("APPROVE"),
                states.get("APPROVED"),
                permissions.get("INVOICE_APPROVE")
        );

        createTransition(
                workflow,
                states.get("PENDING_APPROVAL"),
                actions.get("REJECT"),
                states.get("REJECTED"),
                permissions.get("INVOICE_REJECT")
        );

        createTransition(
                workflow,
                states.get("PENDING_APPROVAL"),
                actions.get("SEND_BACK"),
                states.get("DRAFT"),
                permissions.get("INVOICE_SEND_BACK")
        );

        createTransition(
                workflow,
                states.get("APPROVED"),
                actions.get("CANCEL"),
                states.get("CANCELLED"),
                permissions.get("INVOICE_CANCEL")
        );
    }

    // =============================================================
    // ROLE
    // =============================================================

    private Role findOrCreateRole(
            String name,
            String label
    ) {

        return roleRepository
                .findByName(name)
                .orElseGet(() ->
                        roleRepository.save(
                                Role.builder()
                                        .name(name)
                                        .label(label)
                                        .build()
                        )
                );
    }

    // =============================================================
    // PERMISSION
    // =============================================================

    private Permission findOrCreatePermission(
            String name,
            String label
    ) {

        return permissionRepository
                .findByName(name)
                .orElseGet(() ->
                        permissionRepository.save(
                                Permission.builder()
                                        .name(name)
                                        .label(label)
                                        .build()
                        )
                );
    }

    // =============================================================
    // ROLE -> PERMISSION
    // =============================================================

    private void assignPermission(
            Role role,
            Permission permission
    ) {

        roleRepository.assignPermission(
                role.getId(),
                permission.getId()
        );
    }


    // =============================================================
    // STATE
    // =============================================================

    private WorkflowState findOrCreateState(
            WorkflowDefinition workflow,
            String code,
            String name,
            String description,
            boolean initialState,
            boolean finalState,
            int displayOrder
    ) {

        return workflowStateRepository
                .findByWorkflowDefinitionIdAndCode(
                        workflow.getId(),
                        code
                )
                .orElseGet(() ->
                        workflowStateRepository.save(
                                WorkflowState.builder()
                                        .workflowDefinition(workflow)
                                        .code(code)
                                        .name(name)
                                        .description(description)
                                        .initialState(initialState)
                                        .finalState(finalState)
                                        .active(true)
                                        .displayOrder(displayOrder)
                                        .build()
                        )
                );
    }

    // =============================================================
    // ACTION
    // =============================================================

    private WorkflowActionDefinition findOrCreateAction(
            WorkflowDefinition workflow,
            String code,
            String name,
            String description,
            int displayOrder,
            String uiStyle,
            boolean commentsRequired
    ) {

        return actionDefinitionRepository
                .findByWorkflowDefinitionIdAndActionCode(
                        workflow.getId(),
                        code
                )
                .orElseGet(() ->
                        actionDefinitionRepository.save(
                                WorkflowActionDefinition.builder()
                                        .workflowDefinition(workflow)
                                        .actionCode(code)
                                        .actionName(name)
                                        .description(description)
                                        .displayOrder(displayOrder)
                                        .uiStyle(uiStyle)
                                        .commentsRequired(
                                                commentsRequired
                                        )
                                        .active(true)
                                        .build()
                        )
                );
    }

    // =============================================================
    // TRANSITION
    // =============================================================

    private void createTransition(
            WorkflowDefinition workflow,
            WorkflowState fromState,
            WorkflowActionDefinition action,
            WorkflowState toState,
            Permission requiredPermission
    ) {

        WorkflowTransition transition =
                workflowTransitionRepository
                        .findByWorkflowDefinition_IdAndFromState_IdAndAction_ActionId(
                                workflow.getId(),
                                fromState.getId(),
                                action.getActionId()
                        )
                        .orElse(null);

        if (transition == null) {

            transition =
                    WorkflowTransition.builder()
                            .workflowDefinition(workflow)
                            .fromState(fromState)
                            .toState(toState)
                            .action(action)
                            .requiredPermission(requiredPermission)
                            .active(true)
                            .build();

        } else {

            // Important for existing database records.
            // Seeder also updates permission if it has changed.
            transition.setToState(toState);
            transition.setRequiredPermission(requiredPermission);
            transition.setActive(true);
        }

        workflowTransitionRepository.save(transition);
    }
}