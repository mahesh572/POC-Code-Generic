package com.example.workflow;



import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(
        name = "workflow_task_assignment",
        indexes = {
                @Index(
                        name = "idx_task_assignment_instance",
                        columnList = "workflow_instance_id"
                ),
                @Index(
                        name = "idx_task_assignment_definition",
                        columnList = "task_definition_id"
                ),
                @Index(
                        name = "idx_task_assignment_role",
                        columnList = "role_id"
                ),
                @Index(
                        name = "idx_task_assignment_user",
                        columnList = "assigned_user_id"
                ),
                @Index(
                        name = "idx_task_assignment_status",
                        columnList = "status"
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WorkflowTaskAssignment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "task_assignment_id")
    private Long taskAssignmentId;

    /**
     * Workflow instance for which this task was created.
     *
     * Example:
     * entityType = INVOICE
     * entityId   = 1001
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "workflow_instance_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_task_assignment_instance"
            )
    )
    private WorkflowInstance workflowInstance;

    /**
     * Task definition that generated this task.
     *
     * Example:
     * INVOICE_APPROVAL_TASK
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "task_definition_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_task_assignment_definition"
            )
    )
    private WorkflowTaskDefinition taskDefinition;

    /**
     * Assignment rule responsible for creating
     * this assignment.
     *
     * Provides traceability about why/how
     * this task was assigned.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "assignment_rule_id",
            foreignKey = @ForeignKey(
                    name = "fk_task_assignment_rule"
            )
    )
    private WorkflowTaskAssignmentRule assignmentRule;

    /**
     * Role responsible for the task.
     *
     * Example:
     * APPROVER
     *
     * Normally populated when:
     * assignmentType = ROLE
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "role_id",
            foreignKey = @ForeignKey(
                    name = "fk_task_assignment_role"
            )
    )
    private Role role;

    /**
     * Specific user assigned to the task.
     *
     * NULL:
     * Task is available to the assigned role.
     *
     * NON-NULL:
     * Task has been assigned/claimed by a user.
     */
    @Column(name = "assigned_user_id")
    private Long assignedUserId;

    /**
     * Runtime task status.
     *
     * Examples:
     * OPEN
     * CLAIMED
     * COMPLETED
     * CANCELLED
     */
    @Column(
            name = "status",
            nullable = false,
            length = 30
    )
    @Builder.Default
    private String status = WorkflowTaskStatuses.OPEN;

    /**
     * Time at which this task was created.
     */
    @Column(
            name = "assigned_at",
            nullable = false
    )
    private LocalDateTime assignedAt;

    /**
     * User who originally assigned the task.
     *
     * Can be null for automatically generated tasks.
     */
    @Column(name = "assigned_by")
    private Long assignedBy;

    /**
     * SLA due date.
     */
    @Column(name = "due_at")
    private LocalDateTime dueAt;

    /**
     * When a role-based task is claimed by a user.
     */
    @Column(name = "claimed_at")
    private LocalDateTime claimedAt;

    /**
     * User who completed the task.
     */
    @Column(name = "completed_by")
    private Long completedBy;

    /**
     * Time at which task was completed.
     */
    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    /**
     * Time at which task was cancelled.
     */
    @Column(name = "cancelled_at")
    private LocalDateTime cancelledAt;

    @PrePersist
    protected void onCreate() {

        if (assignedAt == null) {
            assignedAt = LocalDateTime.now();
        }

        if (status == null) {
            status = WorkflowTaskStatuses.OPEN;

        }
    }
}
