package com.example.workflow;



import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(
        name = "workflow_task_assignment_rule",
        indexes = {
                @Index(
                        name = "idx_task_assignment_rule_definition",
                        columnList = "task_definition_id"
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WorkflowTaskAssignmentRule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "assignment_rule_id")
    private Long assignmentRuleId;

    /**
     * Task definition this assignment rule belongs to.
     *
     * Example:
     * INVOICE_APPROVAL_TASK
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "task_definition_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_assignment_rule_task_definition"
            )
    )
    private WorkflowTaskDefinition taskDefinition;

    /**
     * Assignment strategy.
     *
     * Examples:
     * ROLE
     * USER
     * CREATED_BY
     * ENTITY_OWNER
     * MANAGER
     */
    @Column(
            name = "assignment_type",
            nullable = false,
            length = 50
    )
    private String assignmentType;

    /**
     * Used when assignment_type = ROLE.
     *
     * Example:
     * APPROVER
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "role_id",
            foreignKey = @ForeignKey(
                    name = "fk_assignment_rule_role"
            )
    )
    private Role role;

    /**
     * Used when assignment_type = USER.
     *
     * Can later be replaced with a @ManyToOne
     * relationship if you have a User entity.
     */
    @Column(name = "user_id")
    private Long userId;

    /**
     * Lower value means higher priority.
     */
    @Column(
            name = "priority",
            nullable = false
    )
    @Builder.Default
    private Integer priority = 1;

    @Column(
            name = "active",
            nullable = false
    )
    @Builder.Default
    private boolean active = true;
}
