package com.example.workflow;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(
        name = "workflow_transition",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_workflow_transition",
                        columnNames = {
                                "workflow_definition_id",
                                "from_state_id",
                                "action_definition_id"
                        }
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WorkflowTransition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "workflow_definition_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_transition_workflow_definition"
            )
    )
    private WorkflowDefinition workflowDefinition;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "from_state_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_transition_from_state"
            )
    )
    private WorkflowState fromState;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "to_state_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_transition_to_state"
            )
    )
    private WorkflowState toState;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "action_definition_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_transition_action"
            )
    )
    private WorkflowActionDefinition action;

    /**
     * Permission required to view and execute this transition.
     *
     * Examples:
     * INVOICE_SUBMIT
     * INVOICE_APPROVE
     * INVOICE_REJECT
     * INVOICE_SEND_BACK
     * INVOICE_CANCEL
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "required_permission_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_transition_required_permission"
            )
    )
    private Permission requiredPermission;

    @Column(name = "active", nullable = false)
    @Builder.Default
    private boolean active = true;
}