package com.example.workflow;



public final class WorkflowAssignmentTypes {

    private WorkflowAssignmentTypes() {
    }

    public static final String ROLE = "ROLE";
    public static final String USER = "USER";
    public static final String CREATED_BY = "CREATED_BY";
    public static final String ENTITY_OWNER = "ENTITY_OWNER";
    public static final String MANAGER = "MANAGER";
}

