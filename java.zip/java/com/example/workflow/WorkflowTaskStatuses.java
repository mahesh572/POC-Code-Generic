package com.example.workflow;



public final class WorkflowTaskStatuses {

    private WorkflowTaskStatuses() {
    }

    public static final String OPEN = "OPEN";
    public static final String CLAIMED = "CLAIMED";
    public static final String COMPLETED = "COMPLETED";
    public static final String CANCELLED = "CANCELLED";
}