package com.example.workflow;



import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(
        name = "workflow_state",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_workflow_state_code",
                        columnNames = {"workflow_definition_id", "code"}
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WorkflowState {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "workflow_definition_id",
            nullable = false,
            foreignKey = @ForeignKey(name = "fk_state_workflow_definition")
    )
    private WorkflowDefinition workflowDefinition;  // 1

    @Column(name = "code", nullable = false, length = 50)
    private String code;  // DRAFT, SUBMITTED, APPROVED, REJECTED

    @Column(name = "name", nullable = false, length = 100)
    private String name; // Draft, Submitted, Approved, Rejected

    @Column(name = "description", length = 500)
    private String description;

    @Column(name = "initial_state", nullable = false)
    @Builder.Default
    private boolean initialState = false;

    @Column(name = "final_state", nullable = false)
    @Builder.Default
    private boolean finalState = false;

    @Column(name = "active", nullable = false)
    @Builder.Default
    private boolean active = true;

    @Column(name = "display_order")
    private Integer displayOrder;
}
