package com.example.workflow;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(
        name = "workflow_task_definition",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_workflow_task_definition",
                        columnNames = {
                                "workflow_definition_id",
                                "task_code"
                        }
                )
        },
        indexes = {
                @Index(
                        name = "idx_task_definition_workflow_state",
                        columnList = "workflow_definition_id, workflow_state_id"
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WorkflowTaskDefinition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "task_definition_id")
    private Long taskDefinitionId;


    /**
     * Workflow definition to which this task belongs.
     *
     * Example:
     * INVOICE_APPROVAL
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "workflow_definition_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_task_definition_workflow"
            )
    )
    private WorkflowDefinition workflowDefinition;


    /**
     * Workflow state in which this task becomes active.
     *
     * Example:
     * PENDING_APPROVAL
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "workflow_state_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_task_definition_state"
            )
    )
    private WorkflowState workflowState;


    /**
     * Internal task code.
     *
     * Examples:
     * INVOICE_APPROVAL_TASK
     * FINANCE_REVIEW_TASK
     */
    @Column(
            name = "task_code",
            nullable = false,
            length = 100
    )
    private String taskCode;


    /**
     * Display name shown to the user.
     *
     * Example:
     * Approve Invoice
     */
    @Column(
            name = "task_name",
            nullable = false,
            length = 150
    )
    private String taskName;


    /**
     * Description of the task.
     */
    @Column(
            name = "description",
            length = 500
    )
    private String description;


    /**
     * Default role responsible for this task.
     *
     * Example:
     * APPROVER
     *
     * At runtime the task may later be assigned
     * to a specific user.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "default_role_id",
            foreignKey = @ForeignKey(
                    name = "fk_task_definition_role"
            )
    )
    private Role defaultRole;


    /**
     * Controls display ordering.
     */
    @Column(name = "display_order")
    private Integer displayOrder;


    /**
     * Number of hours allowed to complete the task.
     *
     * Example:
     * 48
     *
     * Can later be used to calculate dueAt
     * on WorkflowTaskAssignment.
     */
    @Column(name = "due_in_hours")
    private Integer dueInHours;


    /**
     * Indicates whether this task definition
     * is currently active.
     */
    @Column(
            name = "active",
            nullable = false
    )
    @Builder.Default
    private boolean active = true;
}