package com.example.workflow;



import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(
        name = "workflow_action_definition",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_workflow_action_code",
                        columnNames = {"workflow_definition_id", "action_code"}
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WorkflowActionDefinition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "action_id")
    private Long actionId;

    /**
     * Workflow this action belongs to.
     *
     * Example:
     * INVOICE_APPROVAL
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "workflow_definition_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_action_workflow_definition"
            )
    )
    private WorkflowDefinition workflowDefinition;

    /**
     * System/internal action code.
     *
     * Examples:
     * SUBMIT
     * APPROVE
     * REJECT
     * SEND_BACK
     * CANCEL
     */
    @Column(name = "action_code", nullable = false, length = 50)
    private String actionCode;

    /**
     * Text displayed on UI button.
     *
     * Example:
     * Approve
     * Reject
     * Send Back
     */
    @Column(name = "action_name", nullable = false, length = 100)
    private String actionName;

    @Column(name = "description", length = 500)
    private String description;

    // actionType can be used to categorize actions, for example:
    @Column(name = "action_type", length = 50)
    private String actionType; // e.g., "primary", "secondary", "danger"

    /**
     * Useful for controlling button ordering.
     */
    @Column(name = "display_order")
    private Integer displayOrder;

    /**
     * Can be used by the frontend for styling.
     *
     * Examples:
     * primary
     * success
     * danger
     * warning
     */
    @Column(name = "ui_style", length = 30)
    private String uiStyle;

    /**
     * Whether comments are required when performing
     * this action.
     *
     * REJECT could require comments, for example.
     */
    @Column(name = "comments_required", nullable = false)
    @Builder.Default
    private boolean commentsRequired = false;

    @Column(name = "active", nullable = false)
    @Builder.Default
    private boolean active = true;
}
