package com.example.workflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WokflowEngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(WokflowEngineApplication.class, args);
	}

}
