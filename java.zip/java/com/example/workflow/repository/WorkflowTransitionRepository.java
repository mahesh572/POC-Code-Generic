package com.example.workflow.repository;




import com.example.workflow.WorkflowActionDefinition;
import com.example.workflow.WorkflowTransition;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface WorkflowTransitionRepository
        extends JpaRepository<WorkflowTransition, Long> {

    boolean existsByWorkflowDefinition_IdAndFromState_IdAndAction_ActionId(
            Long workflowDefinitionId,
            Long fromStateId,
            Long actionId
    );


    Optional<WorkflowTransition>
    findByWorkflowDefinition_IdAndFromState_IdAndAction_ActionId(
            Long workflowDefinitionId,
            Long fromStateId,
            Long actionId
    );

}
