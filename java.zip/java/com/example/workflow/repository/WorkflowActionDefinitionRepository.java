package com.example.workflow.repository;




import com.example.workflow.WorkflowActionDefinition;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface WorkflowActionDefinitionRepository
        extends JpaRepository<WorkflowActionDefinition, Long> {



    Optional<WorkflowActionDefinition>
    findByWorkflowDefinitionIdAndActionCode(
            Long workflowDefinitionId,
            String actionCode
    );
}
