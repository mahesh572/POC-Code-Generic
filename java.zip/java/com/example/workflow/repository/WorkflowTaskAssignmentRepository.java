package com.example.workflow.repository;



import com.example.workflow.WorkflowTaskAssignment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface WorkflowTaskAssignmentRepository
        extends JpaRepository<WorkflowTaskAssignment, Long> {

    List<WorkflowTaskAssignment>
    findByWorkflowInstance_IdAndStatus(
            Long workflowInstanceId,
            String status
    );

    List<WorkflowTaskAssignment>
    findByRole_IdAndStatus(
            Long roleId,
            String status
    );

    List<WorkflowTaskAssignment>
    findByAssignedUserIdAndStatus(
            Long userId,
            String status
    );

    Optional<WorkflowTaskAssignment>
    findByTaskAssignmentIdAndStatus(
            Long taskAssignmentId,
            String status
    );
}
