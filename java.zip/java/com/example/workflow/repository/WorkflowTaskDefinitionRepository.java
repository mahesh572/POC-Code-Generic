package com.example.workflow.repository;



import com.example.workflow.WorkflowTaskDefinition;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface WorkflowTaskDefinitionRepository
        extends JpaRepository<WorkflowTaskDefinition, Long> {

    Optional<WorkflowTaskDefinition>
    findByWorkflowDefinition_IdAndTaskCode(
            Long workflowDefinitionId,
            String taskCode
    );

    List<WorkflowTaskDefinition>
    findByWorkflowDefinition_IdAndWorkflowState_IdAndActiveTrue(
            Long workflowDefinitionId,
            Long workflowStateId
    );
}