package com.example.workflow.repository;




import com.example.workflow.WorkflowState;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface WorkflowStateRepository
        extends JpaRepository<WorkflowState, Long> {

    Optional<WorkflowState> findByWorkflowDefinitionIdAndCode(
            Long workflowDefinitionId,
            String code
    );
}
