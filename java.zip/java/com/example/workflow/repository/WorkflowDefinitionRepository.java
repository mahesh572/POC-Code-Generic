package com.example.workflow.repository;




import com.example.workflow.WorkflowDefinition;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface WorkflowDefinitionRepository
        extends JpaRepository<WorkflowDefinition, Long> {

    Optional<WorkflowDefinition> findByCodeAndVersion(
            String code,
            Integer version
    );
}
