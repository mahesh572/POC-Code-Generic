package com.example.workflow.repository;



import com.example.workflow.Permission;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PermissionRepository
        extends JpaRepository<Permission, Long> {



    Optional<Permission> findByName(String name);
}

