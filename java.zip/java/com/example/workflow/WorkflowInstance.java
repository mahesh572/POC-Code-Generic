package com.example.workflow;




import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(
        name = "workflow_instance",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_workflow_instance_entity",
                        columnNames = {
                                "workflow_definition_id",
                                "entity_type",
                                "entity_id"
                        }
                )
        },
        indexes = {
                @Index(
                        name = "idx_workflow_instance_entity",
                        columnList = "entity_type, entity_id"
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WorkflowInstance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ---------------------------------------------------------
    // Workflow Definition
    // ---------------------------------------------------------

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "workflow_definition_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_instance_workflow_definition"
            )
    )
    private WorkflowDefinition workflowDefinition;

    // ---------------------------------------------------------
    // Current State
    // ---------------------------------------------------------

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "current_state_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_instance_current_state"
            )
    )
    private WorkflowState currentState;

    // ---------------------------------------------------------
    // Business Entity
    // ---------------------------------------------------------

    /**
     * Type of entity using this workflow.
     *
     * Examples:
     * INVOICE
     * PURCHASE_ORDER
     * LEAVE_REQUEST
     * CONTRACT
     */
    @Column(
            name = "entity_type",
            nullable = false,
            length = 100
    )
    private String entityType;

    /**
     * ID of the actual business entity.
     *
     * Example:
     * Invoice.id = 1001
     */
    @Column(
            name = "entity_id",
            nullable = false
    )
    private Long entityId;

    // ---------------------------------------------------------
    // Audit
    // ---------------------------------------------------------

    @Column(
            name = "created_by",
            length = 100
    )
    private String createdBy;

    @Column(
            name = "created_at",
            nullable = false,
            updatable = false
    )
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // ---------------------------------------------------------
    // Optimistic Locking
    // ---------------------------------------------------------

    @Version
    @Column(name = "version")
    private Long version;

    @PrePersist
    protected void onCreate() {

        LocalDateTime now = LocalDateTime.now();

        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}