package com.example.workflow;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(
        name = "workflow_transition_event",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_transition_event",
                        columnNames = {
                                "transition_id",
                                "event_code"
                        }
                )
        },
        indexes = {
                @Index(
                        name = "idx_transition_event_transition",
                        columnList = "transition_id"
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WorkflowTransitionEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "transition_event_id")
    private Long transitionEventId;


    /**
     * Workflow transition that triggers this event.
     *
     * Example:
     *
     * PENDING_INVITATION
     *      |
     *      | SEND_INVITE
     *      v
     * INVITATION_SENT
     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "transition_id",
            nullable = false,
            foreignKey = @ForeignKey(
                    name = "fk_transition_event_transition"
            )
    )
    private WorkflowTransition transition;


    /**
     * Event code understood by the application.
     *
     * Examples:
     *
     * CANDIDATE_INVITE
     * CANDIDATE_ACTION_REQUIRED
     * CANDIDATE_REMINDER
     * CANDIDATE_BGV_COMPLETED
     */
    @Column(
            name = "event_code",
            nullable = false,
            length = 100
    )
    private String eventCode;


    /**
     * Generic event category.
     *
     * Examples:
     *
     * NOTIFICATION
     * AUDIT
     * WEBHOOK
     * INTEGRATION
     */
    @Column(
            name = "event_type",
            nullable = false,
            length = 50
    )
    private String eventType;


    /**
     * Execution order when multiple events
     * are configured for the same transition.
     *
     * Lower number executes first.
     *
     * Example:
     * 1, 2, 3...
     */
    @Column(
            name = "execution_order",
            nullable = false
    )
    @Builder.Default
    private Integer executionOrder = 1;


    /**
     * Determines whether this event configuration
     * is currently active.
     */
    @Column(
            name = "active",
            nullable = false
    )
    @Builder.Default
    private boolean active = true;
}