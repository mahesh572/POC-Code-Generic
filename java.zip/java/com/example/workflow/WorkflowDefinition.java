package com.example.workflow;


import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(
        name = "workflow_definition",
        uniqueConstraints = {
                @UniqueConstraint(
                        name = "uk_workflow_definition_code_version",
                        columnNames = {"code", "version"}
                )
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WorkflowDefinition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "code", nullable = false, length = 100)
    private String code;    // INVOICE_APPROVAL

    @Column(name = "name", nullable = false, length = 150)
    private String name;   // Invoice Approval

    @Column(name = "description", length = 500)
    private String description;

    @Column(name = "version", nullable = false)
    @Builder.Default
    private Integer version = 1;

    @Column(name = "active", nullable = false)
    @Builder.Default
    private boolean active = true;

    @OneToMany(
            mappedBy = "workflowDefinition",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @Builder.Default
    private List<WorkflowState> states = new ArrayList<>();
}
